Hello! This is the bot that DTS runs. In reality it is cloned from a github and little to nothing is done by themselves.
Because of them not giving anyone credit and lying about being developers, disrespecting others, I shared this.

So what is this and how to run it?
    - This contains all the files needed to run the bot.
    - Detailed tutorial on how to run below.


1. Download npm and nodejs for your computer. The code works on windows and linux (On windows just google download npm & nodejs, on linux run this command: sudo apt install npm nodejs).
    - NodeJS download link: https://nodejs.org/en/download/ (npm is included)

2. Open powershell or terminal on this dir. (On windows hold shift and right click and you should see open powershell here, linux just right click and open terminal here).

3. Type this in the powershell or terminal: npm i
    - This will download the dependencies to a folder called node_modules

4. Then last step, to actually run it type this in powershell or terminal: node index
    - That will open WhatsApp web window scan the code and let it load.

5. Enjoy.

If you have anymore questions I'm happy to help/answer them.
    - WhatsApp (+358456614448)

Note it might be possible that I have forgotten to add some dependencies.
 Hence if 4th step says cannot find module, copy paste the module name and run this command on the same powershell or terminal window: npm i replace_this

    - ShellTear